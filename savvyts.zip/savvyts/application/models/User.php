<?php defined('BASEPATH') OR exit('No direct script access allowed'); 
 
class User extends CI_Model{ 
    function __construct() { 
    } 
     
    /* 
     * Fetch user data from the database 
     * @param array filter data based on the passed parameters 
     */ 
    function getRows($params = array()){ 
        $this->db->select('*'); 
        $this->db->from('user_details as a'); 
		$this->db->join('user_contact as b', 'b.user_id=a.id','LEFT'); 
         
        if(array_key_exists("conditions", $params)){ 
            foreach($params['conditions'] as $key => $val){ 
                $this->db->where($key, $val); 
            } 
        } 
        
		if(!empty($params['searchKeyword'])){
            $search = $params['searchKeyword'];
            $likeArr = array('a.name' => $search, 'a.email' => $search);
            $this->db->or_like($likeArr);
        }
		
        if(array_key_exists("returnType",$params) && $params['returnType'] == 'count'){ 
            $result = $this->db->count_all_results(); 
        }else{ 
            if(array_key_exists("id", $params) || array_key_exists("email", $params)){ 
                if(!empty($params['id'])){ 
                    $this->db->where('a.id', $params['id']); 
                }
				if(!empty($params['email'])){ 
                    $this->db->where('a.email', $params['email']); 
                }				
                $query = $this->db->get(); 
                $result = $query->row_array(); 
            }else{ 
                $this->db->order_by('a.id', 'asc'); 
                if(array_key_exists("start",$params) && array_key_exists("limit",$params)){ 
                    $this->db->limit($params['limit'],$params['start']); 
                }elseif(!array_key_exists("start",$params) && array_key_exists("limit",$params)){ 
                    $this->db->limit($params['limit']); 
                } 
                 
                $query = $this->db->get(); 
                $result = ($query->num_rows() > 0)?$query->result_array():FALSE; 
            } 
        } 
         
        // Return fetched data 
        return $result; 
    } 
     
    /* 
     * Insert user data into the database 
     * @param $data data to be inserted 
     */ 
    public function insert($data = array()) { 
	
        if(!empty($data)){ 
            // Add created and modified date if not included 
            $detsarr = array();
			$contarr = array();
			for ($i=0; $i < count($data['name']); $i++) {
				$detsarr = array(
				  'name'   => $data['name'][$i],
				  'dob'   => $data['dob'][$i],
				  'email'   => $data['email'][$i],
				  'created'   => date("Y-m-d H:i:s"),
				  'modified'   => date("Y-m-d H:i:s")
				 );
				 $contarr = array(
				  'phone'   => $data['phone'][$i],
				  'address'   => $data['address'][$i]
				 );

				 // Insert user batch data 
				$this->db->trans_start();
				$insert = $this->db->insert('user_details', $detsarr); 
				$user_id[$i] = $this->db->insert_id(); 

				$contarr['user_id'] = $user_id[$i];
				$this->db->insert('user_contact', $contarr);
				$this->db->trans_complete(); 
			}
        }
		// Return the status 
		return $insert?$user_id:false;		
    }
	
	/*
     * Update user data into the database
     * @param $data array to be update based on the passed parameters
     * @param $id num filter data
     */
    public function update($userDets, $userConts, $id) {
        if(!empty($userDets) && !empty($id)){
            // Add modified date if not included
            if(!array_key_exists("modified", $userDets)){
                $userDets['modified'] = date("Y-m-d H:i:s");
            }
            
            // Update user details
            $update = $this->db->update('user_details', $userDets, array('id' => $id));
			// Update user contact
            $update = $this->db->update('user_contact', $userConts, array('user_id' => $id));
            
            // Return the status
            return $update?true:false;
        }
        return false;
    }
    
    /*
     * Delete user data from the database
     * @param num filter data based on the passed parameter
     */
    public function delete($id){
        // Delete user data
        $delete = $this->db->delete('user_details', array('id' => $id));
		$delete = $this->db->delete('user_contact', array('user_id' => $id));
        
        // Return the status
        return $delete?true:false;
    }
		
}