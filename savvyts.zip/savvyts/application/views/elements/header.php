<!DOCTYPE html>
<html lang="en">  
<head>
<title>USERS</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="//fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900" 	type="text/css" media="all">

<!--load jquery-->
<script src="<?php echo base_url('assets/jquery/jquery.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/jquery/jquery-ui.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/jquery/jquery.validate.min.js'); ?>"></script>

<!-- Stylesheet file -->
<link type="text/css" rel='stylesheet' href="<?php echo base_url('assets/css/bootstrap.min.css'); ?>">
<link type="text/css" rel="stylesheet" href="<?php echo base_url('assets/css/jquery-ui.css'); ?>" />
<link type='text/css' rel='stylesheet' href="<?php echo base_url('assets/css/style.css'); ?>" />


</head>
<body>
