<div class="container">
    <h2><?php echo $title; ?></h2>
    <a href="<?php echo site_url('users'); ?>" class="btn btn-primary" style="float:right;">Back To List</a>
    <div class="col-md-6">
        <div class="card" style="width:400px">
            <div class="card-body">
                <p class="card-title"><b>Name:</b> <?php echo $user['name']; ?></p>
				<p class="card-text"><b>DOB:</b> <?php echo date('d-m-Y',strtotime($user['dob'])); ?></p>
                <p class="card-text"><b>Email:</b> <?php echo $user['email']; ?></p>
                <p class="card-text"><b>Phone:</b> <?php echo $user['phone']; ?></p>
                <p class="card-text"><b>Address:</b> <?php echo $user['address']; ?></p>
            </div>
        </div>
    </div>
</div>