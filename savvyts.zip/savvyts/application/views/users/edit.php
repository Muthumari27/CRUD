<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<h2><?php echo $title; ?></h2>
	<!-- Status message -->
    <?php  
        if(!empty($success_msg)){ 
            echo '<p class="status-msg success">'.$success_msg.'</p>'; 
        }elseif(!empty($error_msg)){ 
            echo '<p class="status-msg error">'.$error_msg.'</p>'; 
        } 
    ?>
	
	<!-- Registration form -->
    <div class="regisFrm">
        <form action="" method="post" enctype="multipart/form-data" class="userForm">
            <div class="form-group">
				<label>Name </label>
                <input type="text" name="name" id="name" placeholder="Name" value="<?php echo !empty($this->input->post('name'))?$this->input->post('name'):$user['name']; ?>" />
                <?php echo form_error('name','<p class="help-block">','</p>'); ?>
            </div>
            <div class="form-group">
				<label>Email </label>
                <input type="email" name="email" id="email" placeholder="Email" value="<?php echo !empty($this->input->post('email'))?$this->input->post('email'):$user['email']; ?>" />
                <?php echo form_error('email','<p class="help-block">','</p>'); ?>
            </div>
			<div class="form-group">
				<label>Confirm Email </label>
                <input type="email" name="conf_email" id="conf_email" placeholder="Confirm Email" value="<?php echo !empty($this->input->post('conf_email'))?$this->input->post('conf_email'):$user['email']; ?>" />
                <?php echo form_error('conf_email','<p class="help-block">','</p>'); ?>
            </div>
            <div class="form-group">
				<label>Phone </label>
                <input type="text" name="phone" id="phone" placeholder="Phone" value="<?php echo !empty($this->input->post('phone'))?$this->input->post('phone'):$user['phone']; ?>" />
                <?php echo form_error('phone','<p class="help-block">','</p>'); ?>
            </div>
			<div class="form-group">
				<label>DOB </label>
                <input type="text" name="dob"  id="dob" placeholder="YYYY-MM-DD" value="<?php echo !empty($this->input->post('dob'))?$this->input->post('dob'):$user['dob']; ?>" />
                <?php echo form_error('dob','<p class="help-block">','</p>'); ?>
            </div>
			<div class="form-group">
				<label>Address</label>
				<textarea name="address" id="address" placeholder="Address" cols="22" rows="5" ><?php echo !empty($this->input->post('address'))?$this->input->post('address'):$user['address']; ?></textarea>
                <?php echo form_error('address','<p class="help-block">','</p>'); ?>
            </div>
            <div class="send-button">
                <input type="submit" name="Register" value="Submit" class="btn btn-success">
				<a href="<?php echo site_url('users'); ?>" class="btn btn-success">Back to List</a>
            </div>
        </form>
    </div>
	<script type="text/javascript">

	$(document).ready(function() {
		$("#dob").datepicker({dateFormat: 'yy-mm-dd',maxDate: '0',onClose: function() { this.focus(); }});
		$('form.userForm').on('submit', function(event) {

			// adding rules for inputs with class 'comment'
			$('input#name').each(function() {
				$(this).rules("add", 
					{
						required: true,
						messages: {
						required: "Name is Required",
					  }
					})
			}); 
			$('input#dob').each(function() {
				$(this).rules("add", 
					{
						required: true,
						date:true,
						messages: {
						required: "DOB is Required",
					  }
					})
			}); 				
			$('input#email').each(function() {
				$(this).rules("add", 
					{
						required: true,
						email:true,
						messages: {
						required: "Email is Required",
					  }
					})
			});
			$('input#conf_email').each(function() {
				$(this).rules("add", 
					{
						required: true,
						email:true,
						equalTo: "#email",
						messages: {
						required: "Confirm Email is Required",
					  }
					})
			});
			$('input#phone').each(function() {
				$(this).rules("add", 
					{
						required: true,
						number:true,
						digits: true,
						minlength: 10,
						maxlength: 10,
						messages: {
						required: "Phone number is Required",
					  }
					})
			});
			$('textarea#address').each(function() {
				$(this).rules("add", 
					{
						required: true,
						messages: {
						required: "Address is Required",
					  }
					})
			});
				

			// prevent default submit action         
			//event.preventDefault();

			// test if form is valid 
			if($('form.userForm').validate().form()) {
				console.log("validates");
			} else {
				console.log("does not validate");
			}
		})

		// initialize the validator
		$('form.userForm').validate();

	});
	
	</script>