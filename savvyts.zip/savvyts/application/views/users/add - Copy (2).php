<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<h2><?php echo $title; ?></h2>
	<!-- Status message -->
    <p class="error"></p>
	
	<!-- Registration form -->
    <div class="regisFrm">
        <form action="" method="post" enctype="multipart/form-data" class="userForm" id="userForm">
		<table class="table table-responsive table-striped table-bordered">
			<thead>
				<tr>
					<td>Name</td>
					<td>DOB</td>
					<td>Email</td>
					<td>Confirm Email</td>
					<td>Phone</td>
					<td>Address</td>
					<td></td>
				</tr>
			</thead>
			<tbody id="TextBoxContainer">
			<tr id="row0">
				<td><input type="text" class="name" name="name[0]" placeholder="Name" value="<?php echo set_value('name[0]'); ?>" /><?php echo form_error('name[0]','<p class="help-block">','</p>'); ?></td>
				<td><input type="text" class="dob" name="dob[0]"placeholder="YYYY-MM-DD" value="<?php echo set_value('dob[0]'); ?>"/><?php echo form_error('dob[0]','<p class="help-block">','</p>'); ?></td>
				<td><input type="email" class="email" name="email[0]" placeholder="Email" value="<?php echo set_value('email[0]'); ?>"/><?php echo form_error('email[0]','<p class="help-block">','</p>'); ?></td>
				<td><input type="email" class="conf_email" name="conf_email[0]" placeholder="Confirm Email" value="<?php echo set_value('conf_email[0]'); ?>" /><?php echo form_error('conf_email[0]','<p class="help-block">','</p>'); ?></td>
				<td><input type="text" class="phone" name="phone[0]" placeholder="Phone" value="<?php echo set_value('phone[0]'); ?>" /><?php echo form_error('phone[0]','<p class="help-block">','</p>'); ?></td>
				<td><textarea class="address" name="address[0]" placeholder="Address" cols="22" rows="5"><?php echo set_value('address[0]'); ?></textarea><?php echo form_error('address[0]','<p class="help-block">','</p>'); ?></td>
				<td></td>
			<tr>
			</tbody>
			<tfoot>
			  <tr>
				<th colspan="6">
				<button id="btnAdd" type="button" class="btn btn-primary" data-toggle="tooltip" data-original-title="Add more controls"><i class="glyphicon glyphicon-plus-sign"></i>&nbsp; Add Row&nbsp;</button></th>
			  </tr>
			</tfoot>
			</TABLE>
            <div class="send-button">
				<input type="submit" name="Register" value="Submit" id="regSubmit" class="btn btn-success">
			    <a href="<?php echo site_url('users'); ?>" class="btn btn-success">Back to List</a>
                
            </div>
        </form>
    </div>
	<script type="text/javascript">
		$(document).ready(function() {
			$('body').on('focus',".dob", function(){
			  $(this).datepicker({dateFormat: 'yy-mm-dd',maxDate: '0',onClose: function() { this.focus(); }});
			});

			var numberIncr = 1; // used to increment the name for the inputs

			function addInput() {
				$('#TextBoxContainer').append($('<tr id="row'+numberIncr+'"><td ><input type="text" class="name" name = "name['+numberIncr+']" value = "<?php echo set_value("name['+numberIncr+']"); ?>" placeholder="Name" /><?php echo form_error("name['+numberIncr+']"); ?></td>' + '<td><input type="text" class="dob" name = "dob['+numberIncr+']" value = "<?php echo set_value("dob['+numberIncr+']"); ?>" placeholder="YYYY-MM-DD"/><?php echo form_error("dob['+numberIncr+']"); ?></td>' + '<td><input type="email" class="email" name = "email['+numberIncr+']" value = "<?php echo set_value("email['+numberIncr+']"); ?>" placeholder="Email"  /><?php echo form_error("email['+numberIncr+']"); ?></td>' + '<td><input type="email" class="conf_email" name = "conf_email['+numberIncr+']" value = "<?php echo set_value("conf_email['+numberIncr+']"); ?>" placeholder="Confirm Email"  /><?php echo form_error("conf_email['+numberIncr+']"); ?></td>' + '<td><input type="text" class="phone" name = "phone['+numberIncr+']" value = "<?php echo set_value("phone['+numberIncr+']"); ?>" placeholder="Phone"   /><?php echo form_error("phone['+numberIncr+']"); ?></td>' + '<td><textarea class="address" name="address['+numberIncr+']"  placeholder="Address" cols="22" rows="5"><?php echo set_value("address['+numberIncr+']"); ?></textarea><?php echo form_error("address['+numberIncr+']"); ?></td>' + '<td><button type="button" id="'+numberIncr+'" class="btn btn-danger remove"><i class="glyphicon glyphicon-remove-sign"></i></button></td></tr>'));
				numberIncr++;
			}


			$('form.userForm').on('submit', function(event) {

				// adding rules for inputs with class 'comment'
				$('input.name').each(function() {
					$(this).rules("add", 
						{
							required: true,
							messages: {
							required: "Name is Required",
						  }
						})
				}); 
				$('input.dob').each(function() {
					$(this).rules("add", 
						{
							required: true,
							messages: {
							required: "DOB is Required",
						  }
						})
				}); 				
				$('input.email').each(function() {
					$(this).rules("add", 
						{
							required: true,
							email:true,
							messages: {
							required: "Email is Required",
						  }
						})
				});
				$('input.conf_email').each(function(key, value) {
					$(this).rules("add", 
					{
						required: true,
						email:true,
						equalTo: '[name="email['+key+']"]',
						messages: {
						required: "Confirm Email is Required",
					  }
					})
				});
				$('input.phone').each(function() {
					$(this).rules("add", 
						{
							required: true,
							digits: true,
							minlength: 10,
							maxlength: 10,
							messages: {
							required: "Phone number is Required",
						  }
						})
				});
				$('textarea.address').each(function() {
					$(this).rules("add", 
						{
							required: true,
							messages: {
							required: "Address is Required",
						  }
						})
				});

				// prevent default submit action         
				//event.preventDefault();

				// test if form is valid 
				if($('form.userForm').validate().form()) {
					console.log("validates");
					var formdata = $("#userForm").serialize();
					$.ajax({
						url   :"<?php echo base_url('users/insertMultipleUser'); ?>",
						type  :"post",
						data  :formdata,
						cache :false,
						success:function(json){
							var result = JSON.parse(json);
							if (result.status == true) {
								//$("#userForm")[0].reset();
								window.location.href = "<?php echo base_url('users'); ?>";
							}else{
							     $(".error").html(result.errors);       
							}
							//console.log(result);
						}
					});
					return false;
				} else {
					console.log("does not validate");
				}
			})

			// set handler for addInput button click
			$("#btnAdd").on('click', addInput);
			
			//remove fields
			$("body").on("click", ".remove", function () {
					$(this).closest("tr").remove();
			});

			// initialize the validator
			$('form.userForm').validate();

		});
	</script>