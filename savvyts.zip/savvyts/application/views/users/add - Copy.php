<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<h2><?php echo $title; ?></h2>
	<!-- Status message -->
    <?php  
        if(!empty($success_msg)){ 
            echo '<p class="status-msg success">'.$success_msg.'</p>'; 
        }elseif(!empty($error_msg)){ 
            echo '<p class="status-msg error">'.$error_msg.'</p>'; 
        } 
    ?>
	
	<!-- Registration form -->
    <div class="regisFrm">
        <form action="" method="post" enctype="multipart/form-data" class="userForm">
		<table class="table table-responsive table-striped table-bordered">
			<thead>
				<tr>
					<td>Name</td>
					<td>DOB</td>
					<td>Email</td>
					<td>Confirm Email</td>
					<td>Phone</td>
					<td>Address</td>
					<td></td>
				</tr>
			</thead>
			<tbody id="TextBoxContainer">
			<tr>
				<td><input type="text" id="name" name="name[0]" placeholder="Name" value="<?php echo set_value('name[0]'); ?>" /></td>
				<td><input type="text" id="dob" name="dob[0]"placeholder="YYYY-MM-DD" value="<?php echo set_value('dob[0]'); ?>"/></td>
				<td><input type="email" id="email" name="email[0]" placeholder="Email" value="<?php echo set_value('email[0]'); ?>"  /></td>
				<td><input type="email" id="conf_email" name="conf_email[0]" placeholder="Confirm Email" value="<?php echo set_value('conf_email[0]'); ?>" /></td>
				<td><input type="text" id="phone" name="phone[0]" placeholder="Phone" value="<?php echo set_value('phone[0]'); ?>" /></td>
				<td><textarea id="address" name="address[0]" placeholder="Address" cols="22" rows="5"><?php echo set_value('address[0]'); ?></textarea></td>
				<td></td>
			<tr>
			</tbody>
			<tfoot>
			  <tr>
				<th colspan="6">
				<button id="btnAdd" type="button" class="btn btn-primary" data-toggle="tooltip" data-original-title="Add more controls"><i class="glyphicon glyphicon-plus-sign"></i>&nbsp; Add Row&nbsp;</button></th>
			  </tr>
			</tfoot>
			</TABLE>
            <div class="send-button">
				<input type="submit" name="Register" value="Submit" class="btn btn-success">
			    <a href="<?php echo site_url('users'); ?>" class="btn btn-success">Back to List</a>
                
            </div>
        </form>
    </div>
	<script type="text/javascript">
		$(document).ready(function() {
			//$('body').on('focus',"#dob", function(){
			  $("#dob").datepicker({dateFormat: 'yy-mm-dd',maxDate: '0',onClose: function() { this.focus(); }});
			//});

			var numberIncr = 1; // used to increment the name for the inputs

			function addInput() {
				$('#TextBoxContainer').append($('<tr><td><input type="text" id="name['+numberIncr+']" name = "name['+numberIncr+']" value = "" placeholder="Name" /></td>' + '<td><input type="text" id="dob" name = "dob['+numberIncr+']" value = "" placeholder="YYYY-MM-DD"/></td>' + '<td><input type="email" id="email" name = "email['+numberIncr+']" value = "" placeholder="Email"  /></td>' + '<td><input type="email" id="conf_email" name = "conf_email['+numberIncr+']" value = "" placeholder="Confirm Email"  /></td>' + '<td><input type="text" id="phone" name = "phone['+numberIncr+']" value = "" placeholder="Phone"   /></td>' + '<td><textarea id="address" name="address['+numberIncr+']"  placeholder="Address" cols="22" rows="5"></textarea></td>' + '<td><button type="button" class="btn btn-danger remove"><i class="glyphicon glyphicon-remove-sign"></i></button></td></tr>'));
				numberIncr++;
			}

			$('form.userForm').on('submit', function(event) {
				
				// adding rules for inputs with class 'comment'
				$('input#name').each(function() {
					$(this).rules("add", 
						{
							required: true,
							messages: {
							required: "Name is Required",
						  }
						})
				}); 
				$('input#dob').each(function() {
					$(this).rules("add", 
						{
							required: true,
							date:true,
							messages: {
							required: "DOB is Required",
						  }
						})
				}); 				
				$('input#email').each(function() {
					$(this).rules("add", 
						{
							required: true,
							email:true,
							messages: {
							required: "Email is Required",
						  }
						})
				});
				$('input#conf_email').each(function() {
					$(this).rules("add", 
					{
						required: true,
						email:true,
						equalTo: "#email",
						messages: {
						required: "Confirm Email is Required",
					  }
					})
				});
				$('input#phone').each(function() {
					$(this).rules("add", 
						{
							required: true,
							number:true,
							digits: true,
							minlength: 10,
							maxlength: 10,
							messages: {
							required: "Phone number is Required",
						  }
						})
				});
				$('textarea#address').each(function() {
					$(this).rules("add", 
						{
							required: true,
							messages: {
							required: "Address is Required",
						  }
						})
				});
					

				// prevent default submit action         
				//event.preventDefault();

				// test if form is valid 
				if($('form.userForm').validate().form()) {
					console.log("validates");
				} else {
					console.log("does not validate");
				}
			})

			// set handler for addInput button click
			$("#btnAdd").on('click', addInput);
			
			//remove fields
			$("body").on("click", ".remove", function () {
					$(this).closest("tr").remove();
			});

			// initialize the validator
			$('form.userForm').validate();

		});
	</script>