<div class="container">
    <h2><?php echo $title; ?></h2>
    <!-- Display status message -->
    <?php if(!empty($success_msg)){ ?>
    <div class="col-xs-12">
        <div class="alert alert-success"><?php echo $success_msg; ?></div>
    </div>
    <?php }elseif(!empty($error_msg)){ ?>
    <div class="col-xs-12">
        <div class="alert alert-danger"><?php echo $error_msg; ?></div>
    </div>
    <?php } ?>
    
    <div class="row">
        <div >
            <!-- Search form -->
           <form method="post" class="search-panel">
                <div class="input-group mb-3">
                    <input type="text" name="searchKeyword" class="form-control" placeholder="Search by keyword..." value="<?php echo $searchKeyword; ?>" style="margin-bottom:10px;">&nbsp;&nbsp;<input type="submit" name="submitSearch" class="btn btn-success" value="Search" >&nbsp;&nbsp;&nbsp;
                    <input type="submit" name="submitSearchReset" class="btn btn-success" value="Reset" >
                </div>
            </form>
            
            <!-- Add link -->
            <div style="float:right;">
                <a href="<?php echo site_url('users/add/'); ?>" class="btn btn-success"><i class="plus"></i>Add</a>
            </div>
        </div>
        
        <!-- Data list table --> 
        <table class="table" border=1>
            <thead class="thead-dark">
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
					<th>DOB</th>
					<th>Address</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php 
				if(!empty($users)){ foreach($users as $row){ ?>
                <tr>
                    <td><?php echo $row['name']; ?></td>
                    <td><?php echo $row['email']; ?></td>
                    <td><?php echo $row['phone']; ?></td>
					<td><?php echo date('d-m-Y',strtotime($row['dob'])); ?></td>
					<td><?php echo $row['address']; ?></td>
                    <td>
                        <a href="<?php echo site_url('users/view/'.$row['user_id']); ?>" class="btn btn-primary">View</a>&nbsp;|&nbsp;
                        <a href="<?php echo site_url('users/edit/'.$row['user_id']); ?>" class="btn btn-warning">Edit</a>
                        &nbsp;|&nbsp;<a href="<?php echo site_url('users/delete/'.$row['user_id']); ?>" class="btn btn-danger" onclick="return confirm('Are you sure to delete?')">Delete</a>
                    </td>
                </tr>
                <?php } }else{ ?>
                <tr><td colspan="7">No user(s) found...</td></tr>
                <?php } ?>
            </tbody>
        </table>
    
        <!-- Display pagination links -->
        <div class="pagination">
            <?php echo $this->pagination->create_links(); ?>
        </div>
    </div>
</div>