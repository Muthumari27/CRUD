<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<h2><?php echo $title; ?></h2>
	<!-- Status message -->
    <p class="error"></p>
	
	<!-- Registration form -->
    <div class="regisFrm">
        <form action="" method="post" enctype="multipart/form-data" class="userForm" id="userForm">
		<table class="table table-responsive table-striped table-bordered">
			<thead>
				<tr>
					<td>Name</td>
					<td>DOB</td>
					<td>Email</td>
					<td>Confirm Email</td>
					<td>Phone</td>
					<td>Address</td>
					<td></td>
				</tr>
			</thead>
			<tbody id="TextBoxContainer">
			<tr id="row0">
				<td><input type="text" class="name" name="name[]" id="name_0" placeholder="Name" value="<?php echo set_value('name[]'); ?>" /><?php echo form_error('name[]','<p class="help-block">','</p>'); ?></td>
				<td><input type="text" class="dob" name="dob[]" id="dob_0" placeholder="YYYY-MM-DD" value="<?php echo set_value('dob[]'); ?>"/><?php echo form_error('dob[]','<p class="help-block">','</p>'); ?></td>
				<td><input type="email" class="email" name="email[]" id="email_0" placeholder="Email" value="<?php echo set_value('email[]'); ?>"/><?php echo form_error('email[]','<p class="help-block">','</p>'); ?></td>
				<td><input type="email" class="conf_email" name="conf_email[]" id="conf_email_0" placeholder="Confirm Email" value="<?php echo set_value('conf_email[]'); ?>" data-rule-equalTo="#email_0" /><?php echo form_error('conf_email[]','<p class="help-block">','</p>'); ?></td>
				<td><input type="text" class="phone" name="phone[]" id="phone_0" placeholder="Phone" value="<?php echo set_value('phone[]'); ?>" /><?php echo form_error('phone[]','<p class="help-block">','</p>'); ?></td>
				<td><textarea class="address" name="address[]" id="address_0" placeholder="Address" cols="22" rows="5"><?php echo set_value('address[]'); ?></textarea><?php echo form_error('address[]','<p class="help-block">','</p>'); ?></td>
				<td></td>
			<tr>
			</tbody>
			<tfoot>
			  <tr>
				<th colspan="6">
				<button id="btnAdd" type="button" class="btn btn-primary" data-toggle="tooltip" data-original-title="Add more controls"><i class="glyphicon glyphicon-plus-sign"></i>&nbsp; Add Row&nbsp;</button></th>
			  </tr>
			</tfoot>
			</TABLE>
            <div class="send-button">
				<input type="submit" name="Register" value="Submit" id="regSubmit" class="btn btn-success">
			    <a href="<?php echo site_url('users'); ?>" class="btn btn-success">Back to List</a>
                
            </div>
        </form>
    </div>
	<script type="text/javascript">
		//form is valid submit the form
		$.validator.setDefaults({
			submitHandler: function() {
				console.log("validates");
				var formdata = $("#userForm").serialize();
				$.ajax({
					url   :"<?php echo base_url('users/insertMultipleUser'); ?>",
					type  :"post",
					data  :formdata,
					cache :false,
					success:function(json){
						var result = JSON.parse(json);
						if (result.status == true) {
							//$("#userForm")[0].reset();
							window.location.href = "<?php echo base_url('users'); ?>";
						}else{
							 $(".error").html(result.errors);       
						}
						//console.log(result);
					}
				});
				return false;
			}
		});
		$(document).ready(function() {
			//datepicker
			$('body').on('focus',".dob", function(){
			  $(this).datepicker({dateFormat: 'yy-mm-dd',maxDate: '0',onClose: function() { this.focus(); }});
			});

			var numberIncr = 1; // used to increment the name for the inputs

			function addInput() {
				$('#TextBoxContainer').append($('<tr id="row'+numberIncr+'"><td ><input type="text" class="name" name = "name[]" value = "<?php echo set_value("name[]"); ?>" id="name_'+numberIncr+'" placeholder="Name" /><?php echo form_error("name[]"); ?></td>' + '<td><input type="text" class="dob" name = "dob[]" value = "<?php echo set_value("dob[]"); ?>" id="dob_'+numberIncr+'" placeholder="YYYY-MM-DD"/><?php echo form_error("dob[]"); ?></td>' + '<td><input type="email" class="email" name = "email[]" value = "<?php echo set_value("email[]"); ?>" id="email_'+numberIncr+'" placeholder="Email"  /><?php echo form_error("email[]"); ?></td>' + '<td><input type="email" class="conf_email" name = "conf_email[]" value = "<?php echo set_value("conf_email[]"); ?>" id="conf_email_'+numberIncr+'" placeholder="Confirm Email" data-rule-equalTo="#email_'+numberIncr+'" /><?php echo form_error("conf_email[]"); ?></td>' + '<td><input type="text" class="phone" name = "phone[]" value = "<?php echo set_value("phone[]"); ?>" id="phone_'+numberIncr+'" placeholder="Phone"   /><?php echo form_error("phone[]"); ?></td>' + '<td><textarea class="address" name="address[]"  id="address_'+numberIncr+'" placeholder="Address" cols="22" rows="5"><?php echo set_value("address[]"); ?></textarea><?php echo form_error("address[]"); ?></td>' + '<td><button type="button" id="'+numberIncr+'" class="btn btn-danger remove"><i class="glyphicon glyphicon-remove-sign"></i></button></td></tr>'));
				numberIncr++;
			}
			
			//Validation check
			$("#userForm").validate({
				rules: {
					'name[]': "required",
					'dob[]': "required",
					'email[]': {
						required: true,
						email: true
					},
					'conf_email[]':{
						required: true,
						email: true
					},
					'phone[]':{
						required: true,
						digits: true,
						minlength: 10,
						maxlength: 10
					},
					'address[]':"required"
				},
				ignore: [],
				messages: {
					'name[]': "Name is Required",
					'dob[]': "Dob is Required",
					'email[]': "Email is Required",
					'conf_email[]': {
						required : "Confirm Email is Required"
					},
					'phone[]': {
						required: "Phone number is Required",
						minlength: "Your phone number only 10 numbers",
						maxlength: "Your phone number only 10 numbers",
						digits: "Your phone number is only digits"
					},
					'address[]': "Address is Required"
				}
			});

			// set handler for addInput button click
			$("#btnAdd").on('click', addInput);
			
			//remove fields
			$("body").on("click", ".remove", function () {
					$(this).closest("tr").remove();
			});
		});
	</script>