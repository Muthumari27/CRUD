<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends CI_Controller {

	function __construct() { 
        parent::__construct(); 
        // Load form validation library & user model 
        $this->load->library('form_validation'); 
        $this->load->model('user'); 
		// Load pagination library
        $this->load->library('pagination');
        // Per page limit
        $this->perPage = 5;
		
    }

	public function index(){ 
		$data = array();
		// If search request submitted
		if($this->input->post('submitSearch')){
			$inputKeywords = $this->input->post('searchKeyword');
			$searchKeyword = strip_tags($inputKeywords);
			if(!empty($searchKeyword)){
				$this->session->set_userdata('searchKeyword',$searchKeyword);
			}else{
				$this->session->unset_userdata('searchKeyword');
			}
		}elseif($this->input->post('submitSearchReset')){
			$this->session->unset_userdata('searchKeyword');
		}
		$data['searchKeyword'] = $this->session->userdata('searchKeyword');
		
		// Get rows count
		$conditions['searchKeyword'] = $data['searchKeyword'];
		$conditions['returnType']    = 'count';
		$rowsCount = $this->user->getRows($conditions);
		
		// Pagination config
		$config['base_url']    = base_url().'users/index/';
		$config['uri_segment'] = 3;
		$config['total_rows']  = $rowsCount;
		$config['per_page']    = $this->perPage;
		
		// Initialize pagination library
		$this->pagination->initialize($config);
		
		// Define offset
		$page = $this->uri->segment(3);
		$offset = !$page?0:$page;
		
		// Get rows
		$conditions['returnType'] = '';
		$conditions['start'] = $offset;
		$conditions['limit'] = $this->perPage;
		$data['users'] = $this->user->getRows($conditions);
		$data['title'] = 'Dashboard';
		$this->load->view('elements/header');
		$this->load->view('users/dashboard', $data);
		$this->load->view('elements/footer');			
	}
	
	public function add(){
		$data['title'] = 'User Registration Form';        
        // Load view 
        $this->load->view('elements/header', $data); 
        $this->load->view('users/add', $data); 
        $this->load->view('elements/footer'); 
    } 
	
	public function view($id){
        $data = array();
        
        // Check whether user id is not empty		
        if(!empty($id)){
            $data['user'] = $this->user->getRows(array('id' => $id));;
            $data['title']  = 'User Details';
            
            // Load the details page view
            $this->load->view('elements/header', $data);
            $this->load->view('users/view', $data);
            $this->load->view('elements/footer');
        }else{
            redirect('users');
        }
    }
	
	public function edit($id){
        $data = array();
        
        // Get user data
        $userData = $this->user->getRows(array('id' => $id));
        
        // If update request is submitted
        if($this->input->post('Register')){
            // Form field validation rules
            $this->form_validation->set_rules('name', 'Name', 'trim|required'); 
			$this->form_validation->set_rules('dob', 'DateOfBirth', 'trim|required');
            $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email'); 
			$this->form_validation->set_rules('conf_email', 'Confirm Email', 'trim|required|matches[email]');
            $this->form_validation->set_rules('phone', 'Phone', 'trim|required|callback_valid_mobileno_check'); 
			$this->form_validation->set_rules('address', 'Address', 'trim|required');
            
			// Prepare user data
            $userDets = array( 
				'name' => strip_tags($this->input->post('name')), 
                'email' => strip_tags($this->input->post('email')), 
				'dob' => strip_tags($this->input->post('dob'))
            ); 
			
			$userConts = array( 
                'phone' => strip_tags($this->input->post('phone')), 
                'address' => strip_tags($this->input->post('address'))
            ); 
			
			// Validate submitted form data
            if($this->form_validation->run() == true){
                // Update user data
                $update = $this->user->update($userDets, $userConts, $id);

                if($update){
                    $this->session->set_userdata('success_msg', 'user has been updated successfully.');
                    redirect('users');
                }else{
                    $data['error_msg'] = 'Some problems occured, please try again.';
                }
            }
        }

        $data['user'] = $userData;
		$data['title'] = 'Update User';
		
        // Load the edit page view
        $this->load->view('elements/header', $data);
        $this->load->view('users/edit', $data);
        $this->load->view('elements/footer');
    }
    
    public function delete($id){
        // Check whether user id is not empty
        if($id){
            // Delete user
            $delete = $this->user->delete($id);
            
            if($delete){
                $this->session->set_userdata('success_msg', 'user has been removed successfully.');
            }else{
                $this->session->set_userdata('error_msg', 'Some problems occured, please try again.');
            }
        }
        
        // Redirect to the list page
        redirect('users');
    }
	
	// Valid mobile number check  using expression
	public function valid_mobileno_check($value){
		$value = trim($value);
		if ($value == '') {
			return TRUE;
		}
		else
		{
			if (preg_match('/^\(?[0-9]{3}\)?[-. ]?[0-9]{3}[-. ]?[0-9]{4}$/', $value))
			{
				return preg_replace('/^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/', '($1) $2-$3', $value);
			}
			else
			{
				$this->form_validation->set_message('valid_mobileno_check', 'The mobile number is invalid.'); 
				return FALSE;
			}
		}
	}	
	
	public function insertMultipleUser(){
		
		$data = $userData = array(); 
		
		$userData = count($this->input->post('name'));
		
		if($userData>0){ 
			// Form field validation rules
			for($i=0; $i<count($this->input->post('name')); $i++){
				$this->form_validation->set_rules('name['.$i.']', 'Name', 'required'); 
				$this->form_validation->set_rules('dob['.$i.']', 'DateOfBirth', 'required');
				$this->form_validation->set_rules('email['.$i.']', 'Email', 'required|valid_email'); 
				$this->form_validation->set_rules('conf_email['.$i.']', 'Confirm Email', 'required|matches[email['.$i.']]');
				$this->form_validation->set_rules('phone['.$i.']', 'Phone', 'required|callback_valid_mobileno_check'); 
				$this->form_validation->set_rules('address['.$i.']', 'Address', 'required');
            }
			
            $userData = array( 
				'name' => $this->input->post('name'),
				'dob' => $this->input->post('dob'),				
                'email' => $this->input->post('email'), 
                'phone' => $this->input->post('phone'), 
                'address' => $this->input->post('address')
            ); 

			// Validate submitted form data
            if($this->form_validation->run() == true){
                // Insert user data													
				$insert = $this->user->insert($userData);
                if($insert){ 
                    //$this->session->set_userdata('success_msg', 'User registration has been successful.'); 
					$data['status'] = TRUE;
                    //redirect('users'); 
                }else{ 
                    $data['errors'] = 'Some problems occured, please try again.'; 
					$data['status'] = FALSE;
                } 
            }else{
				$data['errors'] = validation_errors();
				$data['status'] = FALSE;
            }
		}
		echo json_encode($data);
	}
}